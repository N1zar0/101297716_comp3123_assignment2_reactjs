import React from 'react';
import Login from './components/Login';
import EmployeeList from './components/EmployeeList';

function App() {
  return (
    <div>
      <Login />
      <EmployeeList />
    </div>
  );
}

export default App;
